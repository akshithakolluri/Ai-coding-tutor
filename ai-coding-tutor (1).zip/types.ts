
export interface Message {
  role: 'user' | 'model';
  content: string;
}

export const SupportedLanguages = [
  'Python',
  'JavaScript',
  'TypeScript',
  'Java',
  'C',
  'C++',
  'HTML',
  'CSS',
  'SQL',
  'Go',
  'Rust',
] as const;

export type Language = typeof SupportedLanguages[number];
