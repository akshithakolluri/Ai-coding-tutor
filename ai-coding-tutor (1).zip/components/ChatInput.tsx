
import React, { useRef, useEffect } from 'react';
import { PaperAirplaneIcon } from './icons/PaperAirplaneIcon';

interface ChatInputProps {
  input: string;
  setInput: (input: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ input, setInput, onSubmit, isLoading }) => {
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            const scrollHeight = textareaRef.current.scrollHeight;
            const maxHeight = 200; // max height of 200px
            textareaRef.current.style.height = `${Math.min(scrollHeight, maxHeight)}px`;
            textareaRef.current.style.overflowY = scrollHeight > maxHeight ? 'auto' : 'hidden';
        }
    }, [input]);

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (!isLoading && input.trim()) {
                onSubmit();
            }
        }
    };

    return (
        <div className="bg-slate-800/70 backdrop-blur-md p-4 sticky bottom-0 border-t border-slate-700">
            <div className="container mx-auto px-4">
                <form
                    onSubmit={(e) => {
                        e.preventDefault();
                        if (input.trim()) onSubmit();
                    }}
                    className="flex items-end gap-3"
                >
                    <textarea
                        ref={textareaRef}
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={handleKeyDown}
                        rows={1}
                        placeholder="Ask a coding question..."
                        className="flex-1 bg-slate-700 text-slate-200 rounded-lg p-3 resize-none focus:ring-2 focus:ring-cyan-500 focus:outline-none disabled:opacity-50 transition-all"
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        disabled={isLoading || !input.trim()}
                        className="bg-cyan-600 text-white rounded-lg p-3 h-12 w-12 flex items-center justify-center hover:bg-cyan-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors flex-shrink-0"
                    >
                        {isLoading ? (
                            <div className="w-6 h-6 border-t-2 border-white border-solid rounded-full animate-spin"></div>
                        ) : (
                            <PaperAirplaneIcon className="w-6 h-6" />
                        )}
                    </button>
                </form>
            </div>
        </div>
    );
};

export default ChatInput;
