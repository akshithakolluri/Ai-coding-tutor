
import React from 'react';
import type { Message } from '../types';
import CodeBlock from './CodeBlock';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isModel = message.role === 'model';

  const renderContent = (content: string) => {
    if (!content.trim()) {
      return (
        <div className="flex space-x-1.5 py-1">
          <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: '0s' }}></div>
          <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: '0.1s' }}></div>
          <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
        </div>
      );
    }

    const parts = content.split(/(\`\`\`[\w\s-]*\n[\s\S]*?\n\`\`\`)/g);

    return parts.map((part, index) => {
      const codeBlockMatch = part.match(/^\`\`\`([\w\s-]*)?\n([\s\S]*?)\n\`\`\`$/);
      if (codeBlockMatch) {
        const language = codeBlockMatch[1] ? codeBlockMatch[1].trim() : '';
        const code = codeBlockMatch[2];
        return <CodeBlock key={index} language={language} code={code} />;
      } else if (part.trim()) {
        return (
          <p key={index} className="whitespace-pre-wrap my-2 first:mt-0 last:mb-0">
            {part}
          </p>
        );
      }
      return null;
    });
  };

  return (
    <div className={`flex w-full items-start gap-3 ${isModel ? 'justify-start' : 'justify-end'}`}>
       <div className={`max-w-3xl px-5 py-3 rounded-xl shadow-md ${ isModel ? 'bg-slate-700 text-slate-200' : 'bg-cyan-600 text-white' }`}>
        {isModel ? renderContent(message.content) : <p className="whitespace-pre-wrap">{message.content}</p>}
      </div>
    </div>
  );
};

export default ChatMessage;
