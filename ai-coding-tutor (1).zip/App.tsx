
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, Chat } from '@google/genai';

import type { Message, Language } from './types';
import { SYSTEM_PROMPT } from './constants';
import Header from './components/Header';
import LanguageSelector from './components/LanguageSelector';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';
import { CodeBracketIcon } from './components/icons/CodeBracketIcon';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState<string>('');
  const [language, setLanguage] = useState<Language>('Python');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const chatRef = useRef<Chat | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const initializeChat = useCallback(() => {
    try {
      if (!process.env.API_KEY) {
        throw new Error("API key not found. Please ensure the API_KEY environment variable is set.");
      }
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const fullSystemPrompt = `${SYSTEM_PROMPT}\n\nThe user has selected ${language} as their primary language of interest. Tailor your explanations and code examples to ${language} unless the user explicitly asks for another language.`;
      
      chatRef.current = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: fullSystemPrompt,
        },
      });
      setError(null);
    } catch (e) {
        if (e instanceof Error) {
            setError(`Failed to initialize AI Tutor: ${e.message}`);
        } else {
            setError("An unknown error occurred during initialization.");
        }
        console.error(e);
    }
  }, [language]);

  useEffect(() => {
    initializeChat();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [language]);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);
  
  const handleLanguageChange = (newLanguage: Language) => {
    setLanguage(newLanguage);
    setMessages([]); // Reset chat history on language change
  };

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading || !chatRef.current) return;

    const userMessage: Message = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setError(null);

    try {
      setMessages((prev) => [...prev, { role: 'model', content: '' }]);
      const stream = await chatRef.current.sendMessageStream({ message: input });
      
      let modelResponse = '';
      for await (const chunk of stream) {
        modelResponse += chunk.text;
        setMessages((prev) => {
            const newMessages = [...prev];
            newMessages[newMessages.length - 1].content = modelResponse;
            return newMessages;
        });
      }
    } catch (e) {
        const errorMessage = e instanceof Error ? e.message : "An unknown error occurred.";
        setError(`AI response error: ${errorMessage}`);
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].content = `Sorry, I encountered an error: ${errorMessage}`;
          return newMessages;
        })
        console.error(e);
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-900">
      <Header />
      <div className="flex-1 flex flex-col min-h-0">
        <LanguageSelector selectedLanguage={language} onLanguageChange={handleLanguageChange} />
        <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && !isLoading && (
            <div className="flex flex-col items-center justify-center h-full text-slate-500">
                <div className="text-center p-4">
                    <CodeBracketIcon className="w-16 h-16 mx-auto text-slate-600 mb-4" />
                    <h2 className="text-2xl font-semibold text-slate-300">Welcome to the AI Coding Tutor!</h2>
                    <p className="mt-2">Select a language above and ask me anything about coding.</p>
                </div>
            </div>
          )}
          {messages.map((msg, index) => (
            <ChatMessage key={index} message={msg} />
          ))}
        </div>
        {error && (
            <div className="p-4 bg-red-500/10 border-t border-red-500/30 text-red-300 text-center text-sm">
                {error}
            </div>
        )}
        <ChatInput
          input={input}
          setInput={setInput}
          onSubmit={handleSendMessage}
          isLoading={isLoading}
        />
      </div>
    </div>
  );
};

export default App;
